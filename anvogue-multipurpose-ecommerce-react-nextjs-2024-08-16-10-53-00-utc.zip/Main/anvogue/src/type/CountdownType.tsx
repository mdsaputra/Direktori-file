interface CountdownTimeType {
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
}

export default CountdownTimeType;