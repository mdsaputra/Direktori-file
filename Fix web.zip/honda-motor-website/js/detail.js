document.addEventListener("DOMContentLoaded", function () {
    const motorData = {
        "beat-sporty": {
            name: "Honda Beat Sporty",
            image: "images/honda-beat-sporty.jpg",
            description: "Skutik stylish dengan mesin eSP dan PGM-FI yang hemat bahan bakar.",
            specs: ["Mesin 110cc", "Sistem bahan bakar injeksi (PGM-FI)", "Desain ramping dan modern", "Fitur ISS (Idling Stop System)"]
        },
        "scoopy": {
            name: "Honda Scoopy",
            image: "images/honda-scoopy.jpg",
            description: "Skutik dengan desain unik dan fitur canggih, cocok untuk generasi muda yang dinamis.",
            specs: ["Mesin 110cc", "Sistem bahan bakar injeksi (PGM-FI)", "Desain retro modern", "Fitur Smart Key System"]
        },
        "vario-160": {
            name: "Honda Vario 160",
            image: "images/honda-vario-160.jpg",
            description: "Skutik premium dengan mesin 160cc, desain futuristik, dan teknologi canggih.",
            specs: ["Mesin 160cc", "Sistem bahan bakar injeksi (PGM-FI)", "Desain sporty dan agresif", "Fitur ABS (Anti-lock Braking System)"]
        },
        "cbr150r": {
            name: "Honda CBR150R",
            image: "images/honda-cbr150r.jpg",
            description: "Motor sport dengan mesin 150cc DOHC, desain agresif, dan performa tinggi.",
            specs: ["Mesin 150cc DOHC", "Sistem bahan bakar injeksi (PGM-FI)", "Desain full fairing sporty", "Fitur Assist & Slipper Clutch"]
        },
        "cbr250rr": {
            name: "Honda CBR250RR",
            image: "images/honda-cbr250rr.jpg",
            description: "Motor sport 250cc dengan teknologi terkini, desain aerodinamis, dan performa superior.",
            specs: ["Mesin 250cc DOHC", "Sistem bahan bakar injeksi (PGM-FI)", "Desain aerodinamis", "Fitur Throttle By Wire dengan Riding Mode"]
        },
        "supra-x125fi": {
            name: "Honda Supra X 125 FI",
            image: "images/honda-supra-x125fi.jpg",
            description: "Motor bebek andalan dengan mesin 125cc injeksi, irit bahan bakar, dan tangguh.",
            specs: ["Mesin 125cc", "Sistem bahan bakar injeksi (PGM-FI)", "Desain elegan", "Fitur Secure Key Shutter"]
        },
        "super-cub-c125": {
            name: "Honda Super Cub C125",
            image: "images/honda-super-cub-c125.jpg",
            description: "Motor klasik modern dengan desain ikonik, mesin 125cc, dan kenyamanan berkendara.",
            specs: ["Mesin 125cc", "Sistem bahan bakar injeksi (PGM-FI)", "Desain retro klasik", "Fitur Smart Key System"]
        }
    };

    const params = new URLSearchParams(window.location.search);
    const motorKey = params.get("motor");

    if (motorData[motorKey]) {
        document.getElementById("motor-title").innerText = motorData[motorKey].name;
        document.getElementById("motor-image").src = motorData[motorKey].image;
        document.getElementById("motor-name").innerText = motorData[motorKey].name;
        document.getElementById("motor-description").innerText = motorData[motorKey].description;

        const specsList = document.getElementById("motor-specs");
        specsList.innerHTML = "";
        motorData[motorKey].specs.forEach(spec => {
            let li = document.createElement("li");
            li.innerText = spec;
            specsList.appendChild(li);
        });
    } else {
        document.getElementById("motor-title").innerText = "Motor Tidak Ditemukan";
        document.getElementById("motor-name").innerText = "Motor Tidak Ditemukan";
        document.getElementById("motor-description").innerText = "Silakan kembali ke halaman utama dan pilih motor yang tersedia.";
    }
});
