document.addEventListener("DOMContentLoaded", function () {
    // Toggle Menu
    const menuToggle = document.querySelector(".menu-toggle");
    const navMenu = document.querySelector(".nav-menu");

    menuToggle.addEventListener("click", () => {
        navMenu.classList.toggle("active");
    });

    // Navbar Scroll Effect
    window.addEventListener("scroll", function () {
        const navbar = document.querySelector("header");
        if (window.scrollY > 50) {
            navbar.classList.add("scrolled");
        } else {
            navbar.classList.remove("scrolled");
        }
    });

    // Filter Motor
    const filterButtons = document.querySelectorAll(".filter-btn");
    const motorCards = document.querySelectorAll(".motor-card");

    filterButtons.forEach((button) => {
        button.addEventListener("click", function () {
            const category = this.dataset.category;

            filterButtons.forEach((btn) => btn.classList.remove("active"));
            this.classList.add("active");

            motorCards.forEach((card) => {
                if (category === "all" || card.dataset.category === category) {
                    card.style.display = "block";
                } else {
                    card.style.display = "none";
                }
            });
        });
    });

    // CART FUNCTIONALITY
    const cartCountElement = document.getElementById("cart-count");

    function updateCartCount() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cartCountElement.innerText = cart.length; // Menampilkan jumlah item dalam cart
    }

    // Update jumlah cart saat halaman dimuat
    updateCartCount();

    // Tambahkan event listener ke tombol "Tambah ke Cart"
    const addToCartButtons = document.querySelectorAll(".cart-add");

    addToCartButtons.forEach((button) => {
        button.addEventListener("click", function () {
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            let motorName = this.dataset.motor;

            cart.push(motorName); // Tambahkan produk ke array cart
            localStorage.setItem("cart", JSON.stringify(cart));

            updateCartCount(); // Perbarui jumlah cart
            alert(`${motorName} telah ditambahkan ke keranjang!`);
        });
    });
});
