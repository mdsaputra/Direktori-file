document.addEventListener("DOMContentLoaded", function () {
    const cartItemsContainer = document.getElementById("cart-items");
    const cartCountElement = document.getElementById("cart-count");
    const clearCartButton = document.getElementById("clear-cart");
    
    // Cek jika tombol beli ada
    const buyButton = document.createElement("button");
    buyButton.id = "buy-button";
    buyButton.classList.add("btn");
    buyButton.textContent = "Beli";
    buyButton.style.display = "none"; // Sembunyikan awalnya

    cartItemsContainer.appendChild(buyButton);

    function updateCartDisplay() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = "<p>Keranjang belanja kosong.</p>";
            buyButton.style.display = "none";
        } else {
            cartItemsContainer.innerHTML = ""; 
            cart.forEach((item, index) => {
                let itemElement = document.createElement("div");
                itemElement.classList.add("cart-item");
                itemElement.innerHTML = `
                    <p>${item}</p>
                    <button class="remove-item" data-index="${index}">Hapus</button>
                `;
                cartItemsContainer.appendChild(itemElement);
            });

            cartItemsContainer.appendChild(buyButton);
            buyButton.style.display = "block";

            document.querySelectorAll(".remove-item").forEach(button => {
                button.addEventListener("click", function () {
                    let itemIndex = this.dataset.index;
                    cart.splice(itemIndex, 1);
                    localStorage.setItem("cart", JSON.stringify(cart));
                    updateCartDisplay();
                    updateCartCount();
                });
            });
        }
    }

    function updateCartCount() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cartCountElement.innerText = cart.length;
    }

    clearCartButton.addEventListener("click", function () {
        localStorage.removeItem("cart");
        updateCartDisplay();
        updateCartCount();
    });

    buyButton.addEventListener("click", function () {
        showOrderForm();
    });

    function showOrderForm() {
        // Cek apakah formulir sudah ada agar tidak duplikat
        if (document.getElementById("order-form")) return;
    
        const formContainer = document.createElement("div");
        formContainer.id = "order-form";
        formContainer.classList.add("order-form-container");
    
        formContainer.innerHTML = `
            <h2>Formulir Pemesanan</h2>
            <div class="form-group">
                <label for="customer-name">Nama:</label>
                <input type="text" id="customer-name" placeholder="Masukkan nama Anda" required>
            </div>
            <div class="form-group">
                <label for="customer-address">Alamat:</label>
                <textarea id="customer-address" placeholder="Masukkan alamat lengkap" required></textarea>
            </div>
            <button id="send-whatsapp" class="btn">📲 Hubungi via WhatsApp</button>
        `;
    
        document.querySelector(".cart-container").appendChild(formContainer);
    
        document.getElementById("send-whatsapp").addEventListener("click", function () {
            sendWhatsAppMessage();
        });
    }
    

    function sendWhatsAppMessage() {
        const name = document.getElementById("customer-name").value;
        const address = document.getElementById("customer-address").value;
        let cart = JSON.parse(localStorage.getItem("cart")) || [];

        if (!name || !address) {
            alert("Harap isi nama dan alamat terlebih dahulu.");
            return;
        }

        let message = `Halo, saya ingin membeli:\n${cart.join("\n")}\n\nNama: ${name}\nAlamat: ${address}`;
        let encodedMessage = encodeURIComponent(message);
        let whatsappUrl = `https://wa.me/085333284814?text=${encodedMessage}`;

        window.open(whatsappUrl, "_blank");
    }

    updateCartDisplay();
    updateCartCount();
});
